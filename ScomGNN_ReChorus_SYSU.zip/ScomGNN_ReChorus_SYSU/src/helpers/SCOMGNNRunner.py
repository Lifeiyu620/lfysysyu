
# -*- coding: UTF-8 -*-

import os
import gc
import torch
import torch.nn as nn
import logging
import numpy as np
from time import time
from tqdm import tqdm
from torch.utils.data import DataLoader
from typing import Dict, List

from utils import utils
from models.BaseModel import BaseModel


class ScomGNNRunner:
    @staticmethod
    def add_arguments(parser):
        parser.add_argument('--epoch', type=int, default=5, help='Number of epochs.')
        parser.add_argument('--check_epoch', type=int, default=1, help='Check some tensors every check_epoch.')
        parser.add_argument('--test_epoch', type=int, default=1,
                            help='Print test results every test_epoch (-1 means no print).')
        parser.add_argument('--early_stop', type=int, default=10,
                            help='The number of epochs when dev results drop continuously.')
        parser.add_argument('--lr', type=float, default=0.001, help='Learning rate.')
        parser.add_argument('--l2', type=float, default=0, help='Weight decay in optimizer.')
        parser.add_argument('--batch_size', type=int, default=256, help='Batch size during training.')
        parser.add_argument('--eval_batch_size', type=int, default=256, help='Batch size during testing.')
        parser.add_argument('--optimizer', type=str, default='Adam', help='Optimizer: SGD, Adam, Adagrad, Adadelta')
        parser.add_argument('--num_workers', type=int, default=0,
                            help='Number of processors when prepare batches in DataLoader')
        parser.add_argument('--pin_memory', type=int, default=0, help='pin_memory in DataLoader')
        parser.add_argument('--topk', type=str, default='5,10,20,50',
                            help='The number of items recommended to each user.')
        parser.add_argument('--metric', type=str, default='NDCG,HR', help='Metrics: NDCG, HR')
        parser.add_argument('--main_metric', type=str, default='', help='Main metric to determine the best model.')
        return parser

    @staticmethod
    def evaluate(predictions: np.ndarray, topk: list, metrics: list) -> Dict[str, float]:
        evaluations = {}
        gt_rank = (predictions >= predictions[:, 0].reshape(-1, 1)).sum(axis=-1)
        for k in topk:
            hit = (gt_rank <= k)
            for metric in metrics:
                key = f'{metric}@{k}'
                if metric == 'HR':
                    evaluations[key] = hit.mean()
                elif metric == 'NDCG':
                    evaluations[key] = (hit / np.log2(gt_rank + 1)).mean()
                else:
                    raise ValueError(f'Undefined evaluation metric: {metric}.')
        return evaluations

    def __init__(self, args):
        self.train_models = args.train
        self.epochs = args.epoch
        self.check_interval = args.check_epoch
        self.test_interval = args.test_epoch
        self.early_stopping_rounds = args.early_stop
        self.learning_rate = args.lr
        self.train_batch_size = args.batch_size
        self.eval_batch_size = args.eval_batch_size
        self.weight_decay = args.l2
        self.optimizer_type = args.optimizer
        self.dataloader_workers = args.num_workers
        self.dataloader_pin_memory = args.pin_memory
        self.topk_values = [int(x) for x in args.topk.split(',')]
        self.metrics_list = [m.strip().upper() for m in args.metric.split(',')]
        self.main_metric = f'{self.metrics_list[0]}@{self.topk_values[0]}' if not args.main_metric else args.main_metric
        self.main_topk = int(self.main_metric.split("@")[1])
        self.start_time = None
        self.last_step_time = None

        self.log_dir = os.path.dirname(args.log_file)
        self.save_suffix = args.log_file.split("/")[-1].split(".")[0]

    def start_timer(self):
        if not self.start_time:
            self.start_time, self.last_step_time = time(), time()
            return self.start_time
        return None

    def elapsed_time(self):
        if self.start_time:
            current_time = time()
            elapsed = current_time - self.last_step_time
            self.last_step_time = current_time
            return elapsed
        return None

    def get_optimizer(self, model):
        logging.info(f'Optimizer: {self.optimizer_type}')
        return getattr(torch.optim, self.optimizer_type)(model.customize_parameters(), lr=self.learning_rate,
                                                         weight_decay=self.weight_decay)

    def run_training(self, data_dict: Dict[str, BaseModel.Dataset]):
        model = data_dict['train'].model
        main_metric_results, dev_results = [], []
        self.start_timer()
        try:
            for epoch in range(self.epochs):
                self.elapsed_time()
                gc.collect()
                torch.cuda.empty_cache()
                loss = self.train_epoch(data_dict['train'], epoch=epoch + 1)
                print("loss", loss)
                if np.isnan(loss):
                    logging.info(f"Loss is Nan. Stop training at {epoch + 1}.")
                    break
                training_time = self.elapsed_time()

                # Observe selected tensors
                if hasattr(model, 'check_list') and self.check_interval > 0 and epoch % self.check_interval == 0:
                    utils.check(model.check_list)
                logging_str = ""
                if self.test_interval > 0 and epoch % self.test_interval == 0:
                    test_result = self.evaluate(data_dict['dev'], self.topk_values, self.metrics_list)
                    logging_str += f' dev=({utils.format_metric(test_result)})'
                testing_time = self.elapsed_time()
                logging_str += f' [{testing_time:.1f} s]'
                logging.info(logging_str)
        except KeyboardInterrupt:
            logging.info("Early stop manually")
            exit_here = input("Exit completely without evaluation? (y/n) (default n):")
            if exit_here.lower().startswith('y'):
                logging.info(os.linesep + '-' * 45 + ' END: ' + utils.get_time() + ' ' + '-' * 45)
                exit(1)

    def train_epoch(self, dataset: BaseModel.Dataset, epoch=-1) -> float:
        model = dataset.model
        if not hasattr(model, 'optimizer'):
            model.optimizer = self.get_optimizer(model)
        dataset.actions_before_epoch()

        model.train()
        loss_lst = []
        dl = DataLoader(dataset, batch_size=self.train_batch_size, shuffle=True, num_workers=self.dataloader_workers,
                        collate_fn=dataset.collate_batch, pin_memory=self.dataloader_pin_memory)
        for batch in tqdm(dl, leave=False, desc=f'Epoch {epoch}', ncols=100, mininterval=1):
            batch = utils.batch_to_gpu(batch, model.device)
            item_ids = batch['item_id'].to('cuda:0')
            indices = torch.argsort(torch.rand(*item_ids.shape), dim=-1).to('cuda:0')
            batch['item_id'] = torch.gather(item_ids, dim=-1, index=indices)
            model.optimizer.zero_grad()
            loss, _ = model.loss(batch, 'train')
            loss.backward()
            model.optimizer.step()
            loss_lst.append(loss.detach().cpu().data.numpy())
        return np.mean(loss_lst)

    def should_terminate(self, criterion: List[float]) -> bool:
        if len(criterion) > self.early_stopping_rounds and utils.non_increasing(
                criterion[-self.early_stopping_rounds:]):
            return True
        elif len(criterion) - criterion.index(max(criterion)) > self.early_stopping_rounds:
            return True
        return False

    def evaluate_dataset(self, dataset: BaseModel.Dataset, topks: list, metrics: list) -> Dict[str, float]:
        predictions = self.make_predictions(dataset)
        return self.evaluate(predictions, topks, metrics)

    def make_predictions(self, dataset: BaseModel.Dataset, save_prediction: bool = False) -> np.ndarray:
        mode = dataset.phase
        dataset.model.eval()
        predictions = []
        dl = DataLoader(dataset, batch_size=self.eval_batch_size, shuffle=False, num_workers=self.dataloader_workers,
                        collate_fn=dataset.collate_batch, pin_memory=self.dataloader_pin_memory)
        for batch in tqdm(dl, leave=False, ncols=100, mininterval=1, desc='Predict'):
            if hasattr(dataset.model, 'inference'):
                prediction = dataset.model.inference(utils.batch_to_gpu(batch, dataset.model.device))['prediction']
            else:
                prediction = dataset.model(utils.batch_to_gpu(batch, dataset.model.device), mode)['prediction']
            predictions.extend(prediction.cpu().data.numpy())
        predictions = np.array(predictions)

        if dataset.model.test_all:
            print("have testall")
            rows, cols = [], []
            for i, u in enumerate(dataset.data['user_id']):
                clicked_items = list(dataset.corpus.train_clicked_set[u] | dataset.corpus.residual_clicked_set[u])
                idx = list(np.ones_like(clicked_items) * i)
                rows.extend(idx)
                cols.extend(clicked_items)
            predictions[rows, cols] =
