## Tutorials for 3 Basic Tasks

* [Impression-based Ranking/Re-ranking Task](https://github.com/THUwangcy/ReChorus/tree/master/docs/tutorials/Impression_based_Ranking_Reranking.ipynb)
* [CTR Prediction Task](https://github.com/THUwangcy/ReChorus/tree/master/docs/tutorials/CTR_Prediction.ipynb)
* [Context-aware Top-k Recommendation Task](https://github.com/THUwangcy/ReChorus/tree/master/docs/tutorials/Context_aware_Topk_Recommendation.ipynb)